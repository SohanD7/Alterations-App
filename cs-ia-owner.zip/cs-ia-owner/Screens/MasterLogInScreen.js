import React, {Component} from 'react';
import { View, StyleSheet,Text, SafeAreaView, Platform, StatusBar } from 'react-native';


export default class MasterLogInScreen extends Component
{
  render()
  {
    return(
      <View>
      <Text>Master Login Screen</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({

});